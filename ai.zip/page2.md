# Sample page 2 - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* **Sample page 2**

## Sample page 2

