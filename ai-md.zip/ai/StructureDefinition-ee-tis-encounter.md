# EE TIS Encounter - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EE TIS Encounter**

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ee-tis-encounter-definitions.md) 
*  [Mappings](StructureDefinition-ee-tis-encounter-mappings.md) 
*  [XML](StructureDefinition-ee-tis-encounter.profile.xml.md) 
*  [JSON](StructureDefinition-ee-tis-encounter.profile.json.md) 

## Resource Profile: EE TIS Encounter 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/encounter-episode/StructureDefinition/ee-tis-encounter | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:EETISEncounter |

 
A profile for basic encounter. (ee TERVISHOIUKONTAKT v KONTAKT) 

**Usages:**

* Refer to this Profile: [EoC or Encounter reference](StructureDefinition-ee-tis-eoc-or-encounter-reference.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ig-encounter-episode|current/StructureDefinition/ee-tis-encounter)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [EEBaseEncounter](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-encounter.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [EEBaseEncounter](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-encounter.html) 

**Summary**

Mandatory: 1 element

**Structures**

This structure refers to these other structures:

* [EE MPI Patient Verified(https://fhir.ee/mpi/StructureDefinition/ee-mpi-patient-verified)](https://fhir.ee/packages/mpi/1.1.1/site/StructureDefinition-ee-mpi-patient-verified.html)
* [EEBase Patient(https://fhir.ee/base/StructureDefinition/ee-patient)](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-patient.html)
* [EEBase Practitioner(https://fhir.ee/base/StructureDefinition/ee-practitioner)](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-practitioner.html)
* [EEBase RelatedPerson(https://fhir.ee/base/StructureDefinition/ee-related-person)](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-related-person.html)
* [EEBase PractitionerRole(https://fhir.ee/base/StructureDefinition/ee-practitioner-role)](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-practitioner-role.html)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [EEBaseEncounter](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-encounter.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [EEBaseEncounter](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-encounter.html) 

**Summary**

Mandatory: 1 element

**Structures**

This structure refers to these other structures:

* [EE MPI Patient Verified(https://fhir.ee/mpi/StructureDefinition/ee-mpi-patient-verified)](https://fhir.ee/packages/mpi/1.1.1/site/StructureDefinition-ee-mpi-patient-verified.html)
* [EEBase Patient(https://fhir.ee/base/StructureDefinition/ee-patient)](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-patient.html)
* [EEBase Practitioner(https://fhir.ee/base/StructureDefinition/ee-practitioner)](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-practitioner.html)
* [EEBase RelatedPerson(https://fhir.ee/base/StructureDefinition/ee-related-person)](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-related-person.html)
* [EEBase PractitionerRole(https://fhir.ee/base/StructureDefinition/ee-practitioner-role)](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-practitioner-role.html)

 

Other representations of profile: [CSV](StructureDefinition-ee-tis-encounter.csv), [Excel](StructureDefinition-ee-tis-encounter.xlsx), [Schematron](StructureDefinition-ee-tis-encounter.sch) 

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

