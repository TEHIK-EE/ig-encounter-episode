# EoC or Encounter reference - Definitions - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EoC or Encounter reference**

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

*  [Content](StructureDefinition-ee-tis-eoc-or-encounter-reference.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-ee-tis-eoc-or-encounter-reference-mappings.md) 
*  [XML](StructureDefinition-ee-tis-eoc-or-encounter-reference.profile.xml.md) 
*  [JSON](StructureDefinition-ee-tis-eoc-or-encounter-reference.profile.json.md) 

## Extension: ExtensionEETISEoCorEncounterReference - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-07 |

Definitions for the ee-tis-eoc-or-encounter-reference extension.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

