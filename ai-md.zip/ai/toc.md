# Table of Contents - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* **Table of Contents**

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home](index.md) |
| [2 Diagram examples](page1.md) |
| [3 Sample page 2](page2.md) |
| [4 Downloads](downloads.md) |
| [5 Contacts](contacts.md) |
| [6 Search](search.md) |
| [7 Artifacts Summary](artifacts.md) |
| [7.1 EE TIS Encounter](StructureDefinition-ee-tis-encounter.md) |
| [7.2 EE TIS Episode of Care](StructureDefinition-ee-tis-episode-of-care.md) |
| [7.3 EoC or Encounter reference](StructureDefinition-ee-tis-eoc-or-encounter-reference.md) |

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

