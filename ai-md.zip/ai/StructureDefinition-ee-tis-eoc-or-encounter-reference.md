# EoC or Encounter reference - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EoC or Encounter reference**

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ee-tis-eoc-or-encounter-reference-definitions.md) 
*  [Mappings](StructureDefinition-ee-tis-eoc-or-encounter-reference-mappings.md) 
*  [XML](StructureDefinition-ee-tis-eoc-or-encounter-reference.profile.xml.md) 
*  [JSON](StructureDefinition-ee-tis-eoc-or-encounter-reference.profile.json.md) 

## Extension: EoC or Encounter reference 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/encounter-episode/StructureDefinition/ee-tis-eoc-or-encounter-reference | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:ExtensionEETISEoCorEncounterReference |

Extension for the need of referencing episode of care or encounter in EETISEpisodeOfCare profile

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [EE TIS Episode of Care](StructureDefinition-ee-tis-episode-of-care.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ig-encounter-episode|current/StructureDefinition/ee-tis-eoc-or-encounter-reference)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [SupportingInfo](https://build.fhir.org/ig/HL7/fhir-extensions/StructureDefinition-workflow-supportingInfo.html) 

This structure is derived from [SupportingInfo](https://build.fhir.org/ig/HL7/fhir-extensions/StructureDefinition-workflow-supportingInfo.html) 

**Summary**

Simple Extension with the type Reference: Extension for the need of referencing episode of care or encounter in EETISEpisodeOfCare profile

 **Differential View** 

This structure is derived from [SupportingInfo](https://build.fhir.org/ig/HL7/fhir-extensions/StructureDefinition-workflow-supportingInfo.html) 

 **Snapshot View** 

This structure is derived from [SupportingInfo](https://build.fhir.org/ig/HL7/fhir-extensions/StructureDefinition-workflow-supportingInfo.html) 

**Summary**

Simple Extension with the type Reference: Extension for the need of referencing episode of care or encounter in EETISEpisodeOfCare profile

 

Other representations of profile: [CSV](StructureDefinition-ee-tis-eoc-or-encounter-reference.csv), [Excel](StructureDefinition-ee-tis-eoc-or-encounter-reference.xlsx), [Schematron](StructureDefinition-ee-tis-eoc-or-encounter-reference.sch) 

#### Constraints

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

