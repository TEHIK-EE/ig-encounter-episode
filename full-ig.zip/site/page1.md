# Diagram examples - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* **Diagram examples**

## Diagram examples

### Paragraph #1

