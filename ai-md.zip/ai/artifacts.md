# Artifacts Summary - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

## Artifacts Summary

Contents:

*  [Structures: Resource Profiles](#1) 
*  [Structures: Extension Definitions](#2) 

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [EE TIS Encounter](StructureDefinition-ee-tis-encounter.md) | A profile for basic encounter. (ee TERVISHOIUKONTAKT v KONTAKT) |
| [EE TIS Episode of Care](StructureDefinition-ee-tis-episode-of-care.md) | A profile for basic Episode of Care.(ee RAVIEPISOOD) |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [EoC or Encounter reference](StructureDefinition-ee-tis-eoc-or-encounter-reference.md) | Extension for the need of referencing episode of care or encounter in EETISEpisodeOfCare profile |

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

