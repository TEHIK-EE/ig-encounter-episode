# EE TIS Episode of Care - Mappings - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EE TIS Episode of Care**

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

*  [Content](StructureDefinition-ee-tis-episode-of-care.md) 
*  [Detailed Descriptions](StructureDefinition-ee-tis-episode-of-care-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-ee-tis-episode-of-care.profile.xml.md) 
*  [JSON](StructureDefinition-ee-tis-episode-of-care.profile.json.md) 

## Resource Profile: EETISEpisodeOfCare - Mappings

| |
| :--- |
| Draft as of 2025-10-07 |

Mappings for the ee-tis-episode-of-care resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

