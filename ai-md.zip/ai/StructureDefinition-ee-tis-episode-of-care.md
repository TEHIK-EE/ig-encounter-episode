# EE TIS Episode of Care - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EE TIS Episode of Care**

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ee-tis-episode-of-care-definitions.md) 
*  [Mappings](StructureDefinition-ee-tis-episode-of-care-mappings.md) 
*  [XML](StructureDefinition-ee-tis-episode-of-care.profile.xml.md) 
*  [JSON](StructureDefinition-ee-tis-episode-of-care.profile.json.md) 

## Resource Profile: EE TIS Episode of Care 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/encounter-episode/StructureDefinition/ee-tis-episode-of-care | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:EETISEpisodeOfCare |

 
A profile for basic Episode of Care.(ee RAVIEPISOOD) 

**Usages:**

* Refer to this Profile: [EoC or Encounter reference](StructureDefinition-ee-tis-eoc-or-encounter-reference.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ig-encounter-episode|current/StructureDefinition/ee-tis-episode-of-care)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [EEBaseEpisodeOfCare](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-episode-of-care.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [EEBaseEpisodeOfCare](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-episode-of-care.html) 

**Summary**

**Structures**

This structure refers to these other structures:

* [EE MPI Patient Verified(https://fhir.ee/mpi/StructureDefinition/ee-mpi-patient-verified)](https://fhir.ee/packages/mpi/1.1.1/site/StructureDefinition-ee-mpi-patient-verified.html)

**Extensions**

This structure refers to these extensions:

* [https://fhir.ee/encounter-episode/StructureDefinition/ee-tis-eoc-or-encounter-reference](StructureDefinition-ee-tis-eoc-or-encounter-reference.md)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [EEBaseEpisodeOfCare](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-episode-of-care.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [EEBaseEpisodeOfCare](https://fhir.ee/packages/ee-base/1.2.1/site/StructureDefinition-ee-episode-of-care.html) 

**Summary**

**Structures**

This structure refers to these other structures:

* [EE MPI Patient Verified(https://fhir.ee/mpi/StructureDefinition/ee-mpi-patient-verified)](https://fhir.ee/packages/mpi/1.1.1/site/StructureDefinition-ee-mpi-patient-verified.html)

**Extensions**

This structure refers to these extensions:

* [https://fhir.ee/encounter-episode/StructureDefinition/ee-tis-eoc-or-encounter-reference](StructureDefinition-ee-tis-eoc-or-encounter-reference.md)

 

Other representations of profile: [CSV](StructureDefinition-ee-tis-episode-of-care.csv), [Excel](StructureDefinition-ee-tis-episode-of-care.xlsx), [Schematron](StructureDefinition-ee-tis-episode-of-care.sch) 

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

