# Contacts - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* **Contacts**

## Contacts

### Contacts

If you have any problem about Implementation Guide please create new issue on the [GitHub](https://github.com/TEHIK-EE/ig-ee-starter) project page.

If you need further information or wish to provide feedback on this implementation guide, please e-mail [andmekorraldus@tehik.ee](mailto:andmekorraldus@tehik.ee)

