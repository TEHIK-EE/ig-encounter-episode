# EE TIS Encounter - TTL Representation - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EE TIS Encounter**

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

*  [Content](StructureDefinition-ee-tis-encounter.md) 
*  [Detailed Descriptions](StructureDefinition-ee-tis-encounter-definitions.md) 
*  [Mappings](StructureDefinition-ee-tis-encounter-mappings.md) 
*  [XML](StructureDefinition-ee-tis-encounter.profile.xml.md) 
*  [JSON](StructureDefinition-ee-tis-encounter.profile.json.md) 

## Resource Profile: EETISEncounter - TTL Profile

| |
| :--- |
| Draft as of 2025-10-07 |

TTL representation of the ee-tis-encounter resource profile.

[Raw ttl](StructureDefinition-ee-tis-encounter.ttl) | [Download](StructureDefinition-ee-tis-encounter.ttl)

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

