# Search TEHIK FHIR IG Encounter and Episode of Care (Current Build)

