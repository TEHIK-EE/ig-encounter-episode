# Home - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/encounter-episode/ImplementationGuide/ee.fhir.encounterepisode | *Version*:0.1.0 |
| Draft as of 2026-05-15 | *Computable Name*:TEHIKIGEncounterandEpisodeofCare |

### Intro

This implementation guide is for encounter, episode of care and condition.

#### Source code

This IG source code is available in [GitHub](https://github.com/TEHIK-EE/ig-ee-starter).

### How to start

```
```mermaid
graph TD;
    A-->B;
    A-->C;
    B-->D;
    C-->D;
```

```

```
<div class="mermaid">
graph TD;
    A-->B;
    A-->C;
    B-->D;
    C-->D;
</div>

```

### Structure

**input/fsh/*.fsh** files are logically grouped into folders, which are used to generate the website structure. Please follow the same structure when adding new files.

**input/pagecontent** folder contains markdown files which are used to generate the website pages. Menu and page name mappings are defined in **sushi-config.yaml** file.

### Build and deploy

Building and deploying information is located in [GitHub](https://github.com/TEHIK-EE/ig-ee-starter) project [README](https://github.com/TEHIK-EE/ig-ee-starter/blob/main/README.md) file.

