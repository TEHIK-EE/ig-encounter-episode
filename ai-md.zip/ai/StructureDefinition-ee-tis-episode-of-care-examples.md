#  - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

*  [Content](StructureDefinition-ee-tis-episode-of-care.md) 
*  [Detailed Descriptions](StructureDefinition-ee-tis-episode-of-care-definitions.md) 
*  [Mappings](StructureDefinition-ee-tis-episode-of-care-mappings.md) 
*  [XML](StructureDefinition-ee-tis-episode-of-care.profile.xml.md) 
*  [JSON](StructureDefinition-ee-tis-episode-of-care.profile.json.md) 

## Resource Profile: EETISEpisodeOfCare - Examples

| |
| :--- |
| Draft as of 2025-10-07 |

**No examples are currently available for the Profile.**

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

