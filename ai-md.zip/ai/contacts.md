# Contacts - TEHIK FHIR IG Encounter and Episode of Care v0.1.0

* [**Table of Contents**](toc.md)
* **Contacts**

TEHIK FHIR IG Encounter and Episode of Care - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://fhir.ee/encounter-episode/history.html)

## Contacts

### Contacts

If you have any problem about Implementation Guide please create new issue on the [GitHub](https://github.com/TEHIK-EE/ig-ee-starter) project page.

If you need further information or wish to provide feedback on this implementation guide, please e-mail [andmekorraldus@tehik.ee](mailto:andmekorraldus@tehik.ee)

 IG © 2025+ [TEHIK](https://www.tehik.ee). Package ig-encounter-episode#0.1.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

